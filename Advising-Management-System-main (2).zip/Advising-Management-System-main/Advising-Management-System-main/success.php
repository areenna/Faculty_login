<!DOCTYPE html>
<html>
<head>
    <title>Success Page</title>
</head>
<body>
    <h1>Success!</h1>
    <p>Your operation was successful.</p>
    <button onclick="window.location.href='faculty_login.php'">Go to Login</button>
</body>
</html>
