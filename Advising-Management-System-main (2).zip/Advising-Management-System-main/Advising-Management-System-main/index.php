<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Advising Management</title>
</head>
<body>
      <div class="container">
        <div class="box form-box">
            <div class="btn" onclick="location.href='student_Signup.php'">
                For students signup
            </div>
            <div class="btn" onclick="location.href='faculty_Signup.php'">
                For Faculty signup
            </div>
        </div>
      </div>
</body>
</html>
